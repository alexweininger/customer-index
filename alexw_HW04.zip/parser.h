/**
 * list.c
 *
 * file for creating a doubly linked list
 */

// function declarations
DLList *insert(DLList **, DLList *, DLList *, DLList *);
DLList *deleteDLList(DLList **, DLList *, DLList *, int);
DLList *makeDLList(customer);
void printDLList(DLList *);
void printList(DLList *);
void freeLList(DLList *);
